/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utama;

/**
 *
 * @author Achmad
 */
public class Monokotil extends Tumbuhan {
    public  void satuBiji(){
        System.out.println("memiliki satu biji");
    }
}
