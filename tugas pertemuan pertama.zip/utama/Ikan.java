/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utama;

/**
 *
 * @author Achmad
 */
public class Ikan extends Hewan {
    public void hidupDIAir() {
        System.out.println("Saya hidup di air");
    }
    private String jenisSirip;
    private String caraberenang;
    private int jumlahInsang;
    private String jenisAir;

    /**
     * @return the jenisSirip
     */
    public String getJenisSirip() {
        return jenisSirip;
    }

    /**
     * @param jenisSirip the jenisSirip to set
     */
    public void setJenisSirip(String jenisSirip) {
        this.jenisSirip = jenisSirip;
    }

    /**
     * @return the caraberenang
     */
    public String getCaraberenang() {
        return caraberenang;
    }

    /**
     * @param caraberenang the caraberenang to set
     */
    public void setCaraberenang(String caraberenang) {
        this.caraberenang = caraberenang;
    }

    /**
     * @return the jumlahInsang
     */
    public int getJumlahInsang() {
        return jumlahInsang;
    }

    /**
     * @param jumlahInsang the jumlahInsang to set
     */
    public void setJumlahInsang(int jumlahInsang) {
        this.jumlahInsang = jumlahInsang;
    }

    /**
     * @return the jenisAir
     */
    public String getJenisAir() {
        return jenisAir;
    }

    /**
     * @param jenisAir the jenisAir to set
     */
    public void setJenisAir(String jenisAir) {
        this.jenisAir = jenisAir;
    }

}
