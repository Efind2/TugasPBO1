/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utama;

/**
 *
 * @author Achmad
 */
public class Amfibi extends Hewan {

    public void hidupDuaAlam() {
        System.out.println("Hidup di dua alam");
    }
}
