/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package utama;


public class PertemuanSatu {

    public static void main(String[] args) {
        Aves bebek = new Aves();
        System.out.println("ini bebek");
        bebek.berjalan();
        bebek.bernafas(); 
        bebek.setJumlahKaki(2);
        bebek.setJenisMakanan("Omnivora");
        bebek.setCaraReproduksi("bertelur");
        bebek.setJenisParuh("tumpul");
        bebek.setCaraTerbang("tidak bisa terbang");
        System.out.println("jenis yang dimakan " + bebek.getJenisMakanan());
        System.out.println("reproduksi  " + bebek.getCaraReproduksi());
        System.out.println("jumlah kaki  " + bebek.getJumlahKaki());
        System.out.println("dengan paruh  " + bebek.getJenisParuh());
        System.out.println("bisa " + bebek.getCaraTerbang());
        System.out.println();
        Mamalia macan = new Mamalia();
        System.out.println("ini macan");
        macan.berjalan();
        macan.bernafas(); 
        macan.setJumlahKaki(4);
        macan.setJenisMakanan("Karniivora");
        macan.setCaraReproduksi("Melahirkan");
        macan.menyusui();
        System.out.println("mempunyai kaki" + macan.getJumlahKaki());
        System.out.println("jenis makanan " + macan.getJenisMakanan());
        System.out.println("repsrduksi  " + macan.getCaraReproduksi());
        System.out.println();
        Ikan lele = new Ikan();
        System.out.println("ini lele");
        lele.berjalan();
        lele.berkembangbiak();
        lele.tumbuh();
        lele.hidupDIAir();
        lele.setCaraReproduksi("bertelur");
        lele.setJumlahKaki(0);
        lele.setJenisMakanan("Omnivora");
        lele.setCaraberenang("dengan sirip dan tubuh");
        lele.setJenisAir("air tawar");
        lele.setJenisSirip("caudal fin");
        lele.setJumlahInsang(8);
        System.out.println("reproduksi "+ lele.getCaraReproduksi());
        System.out.println("tidak memiliki kaki jadi jumlah kaki "+ lele.getJumlahKaki() );
        System.out.println("termasuk "+ lele.getJenisMakanan());
        System.out.println("bisa berenang "+ lele.getCaraberenang());
        System.out.println("hidup di "+ lele.getJenisAir());
        System.out.println("memiliki sirip dengan jenis " + lele.getJenisSirip());
        System.out.println("memiliki jumlah insang "+ lele.getJumlahInsang());
        System.out.println();
        Reptil buaya = new Reptil();
        System.out.println("ini buaya");
        buaya.berjalan();
        buaya.berkembangbiak();
        buaya.bernafas();
        buaya.setJumlahKaki(4);
        buaya.setCaraReproduksi("bertelur");
        buaya.setJenisSisik("scutes");
        buaya.setJenisMakanan("karnivora");
        System.out.println("jumlah kaki  " + buaya.getJumlahKaki());
        System.out.println("reproduksi  " + buaya.getCaraReproduksi());
        System.out.println("jenis sisik " + buaya.getJenisSisik());
        System.out.println("jenis makanan  "+ buaya.getJenisMakanan());
        
        Amfibi katak = new Amfibi();
        System.out.println("ini katak");
        katak.berjalan();
        katak.berkembangbiak();
        katak.bernafas();
        katak.hidupDuaAlam();
        katak.setJumlahKaki(4);
        katak.setJenisMakanan("karnivora ");
        katak.setCaraReproduksi("bertelur ");
        System.out.println("memiliki kaki "+ katak.getJumlahKaki());
        System.out.println("jenis makanan " + katak.getJenisMakanan());
        System.out.println("reproduksi " + katak.getCaraReproduksi());
        
        System.out.println();
        System.out.println("ini pisang");
        Monokotil pisang = new Monokotil();
        pisang.berkembangbiak();
        pisang.bernafas();
        pisang.setArahDaun("ke bawah");
        pisang.setBentukAkar("serabut");
        pisang.setCaraReproduksi("pembuahan");
        pisang.setJenisDaun("lembaran");
        pisang.setJumlahMahkotaBunga(3);
        pisang.setStrukturBatang("pseudostem");
        pisang.setWarnaDaun("hijau");
        pisang.satuBiji();
        System.out.println("Arah daun  " + pisang.getArahDaun());
        System.out.println("bentuk akar  " + pisang.getBentukAkar());
        System.out.println("jumlah mahkota bungga "+ pisang.getJumlahMahkotaBunga());
        System.out.println("struktur bungga "+ pisang.getStrukturBatang());
        System.out.println("warna daun "+ pisang.getWarnaDaun());
        System.out.println("jenis daun " + pisang.getJenisDaun());
        System.out.println("cara reproduksi " + pisang.getCaraReproduksi());
        
        System.out.println();
        System.out.println("ini mawar");
        Dikotil mawar = new Dikotil();
        mawar.berkembangbiak();
        mawar.bernafas();
        mawar.duaBiji();
        mawar.setArahDaun("ke arah batang");
        mawar.setBentukAkar("serabut");
        mawar.setCaraReproduksi("biji");
        mawar.setJenisDaun("majemuk");
        mawar.setJumlahMahkotaBunga(5);
        mawar.setStrukturBatang("pseudostem");
        mawar.setWarnaDaun("hijau");
        System.out.println("arah daun "+ mawar.getArahDaun());
        System.out.println("bentuk akar " + mawar.getBentukAkar());
        System.out.println("cara reproduksi "+ mawar.getCaraReproduksi());
        System.out.println("jenis daun " + mawar.getJenisDaun());
        System.out.println("jumlah mahkota bunga "+ mawar.getJumlahMahkotaBunga());
        System.out.println("struktur batang " + mawar.getStrukturBatang());
        System.out.println("warna daun " + mawar.getWarnaDaun());
    }
    
}
