/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utama;

public class MakhluqHidup {
    
    public  void bernafas(){
    System.out.println("bisa Bernafas");
    
    }
    public  void tumbuh(){
    System.out.println("bisa Tumbuh");
    
    }public  void berkembangbiak(){
        System.out.println("bisa berkembangbiak");
    }
    private String caraReproduksi;

    /**
     * @return the caraReproduksi
     */
    public String getCaraReproduksi() {
        return caraReproduksi;
    }

    /**
     * @param caraReproduksi the caraReproduksi to set
     */
    public void setCaraReproduksi(String caraReproduksi) {
        this.caraReproduksi = caraReproduksi;
    }
    
}
