/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utama;

public class Hewan extends MakhluqHidup {

    private int JumlahKaki;
    private String jenisMakanan;

    /**
     * @return the JumlahKaki
     */
    public int getJumlahKaki() {
        return JumlahKaki;
    }

    public void setJumlahKaki(int JumlahKaki) {
        this.JumlahKaki = JumlahKaki;
    }

    public void berjalan() {
        System.out.println("bisa Berjalan");
    }

    /**
     * @return the jenisMakanan
     */
    public String getJenisMakanan() {
        return jenisMakanan;
    }

    /**
     * @param jenisMakanan the jenisMakanan to set
     */
    public void setJenisMakanan(String jenisMakanan) {
        this.jenisMakanan = jenisMakanan;
    }
}
