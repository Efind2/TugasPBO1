/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utama;

/**
 *
 * @author Achmad
 */
public class Aves extends Hewan {
    private String jenisParuh;
    private String caraTerbang;

    /**
     * @return the jenisParuh
     */
    public String getJenisParuh() {
        return jenisParuh;
    }

    /**
     * @param jenisParuh the jenisParuh to set
     */
    public void setJenisParuh(String jenisParuh) {
        this.jenisParuh = jenisParuh;
    }

    /**
     * @return the caraTerbang
     */
    public String getCaraTerbang() {
        return caraTerbang;
    }

    /**
     * @param caraTerbang the caraTerbang to set
     */
    public void setCaraTerbang(String caraTerbang) {
        this.caraTerbang = caraTerbang;
    }
     
}
