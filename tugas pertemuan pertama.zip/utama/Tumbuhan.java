/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utama;

/**
 *
 * @author Achmad
 */
public class Tumbuhan extends MakhluqHidup {
    private String warnaDaun;
    private int jumlahMahkotaBunga;
    private String strukturBatang;
    private String bentukAkar;
    private String jenisDaun;

    /**
     * @return the warnaDaun
     */
    public String getWarnaDaun() {
        return warnaDaun;
    }

    /**
     * @param warnaDaun the warnaDaun to set
     */
    public void setWarnaDaun(String warnaDaun) {
        this.warnaDaun = warnaDaun;
    }
    private String arahDaun;

    /**
     * @return the arahDaun
     */
    public String getArahDaun() {
        return arahDaun;
    }

    /**
     * @param arahDaun the arahDaun to set
     */
    public void setArahDaun(String arahDaun) {
        this.arahDaun = arahDaun;
    }

    /**
     * @return the jumlahMahkotaBunga
     */
    public int getJumlahMahkotaBunga() {
        return jumlahMahkotaBunga;
    }

    /**
     * @param jumlahMahkotaBunga the jumlahMahkotaBunga to set
     */
    public void setJumlahMahkotaBunga(int jumlahMahkotaBunga) {
        this.jumlahMahkotaBunga = jumlahMahkotaBunga;
    }

    /**
     * @return the strukturBatang
     */
    public String getStrukturBatang() {
        return strukturBatang;
    }

    /**
     * @param strukturBatang the strukturBatang to set
     */
    public void setStrukturBatang(String strukturBatang) {
        this.strukturBatang = strukturBatang;
    }

    /**
     * @return the bentukAkar
     */
    public String getBentukAkar() {
        return bentukAkar;
    }

    /**
     * @param bentukAkar the bentukAkar to set
     */
    public void setBentukAkar(String bentukAkar) {
        this.bentukAkar = bentukAkar;
    }

    /**
     * @return the jenisDaun
     */
    public String getJenisDaun() {
        return jenisDaun;
    }

    /**
     * @param jenisDaun the jenisDaun to set
     */
    public void setJenisDaun(String jenisDaun) {
        this.jenisDaun = jenisDaun;
    }
}
