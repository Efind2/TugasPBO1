/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utama;

/**
 *
 * @author Achmad
 */
public class Reptil extends Hewan {
    
    private String jenisSisik;

    /**
     * @return the jenisSisik
     */
    public String getJenisSisik() {
        return jenisSisik;
    }

    /**
     * @param jenisSisik the jenisSisik to set
     */
    public void setJenisSisik(String jenisSisik) {
        this.jenisSisik = jenisSisik;
    }
    
}
